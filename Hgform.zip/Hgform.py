import tkinter as tk
from tkinter import *
import qrcode

def cerrar():
    ventanaprincipal.withdraw()

def escribir_datos():
    tipo_pez_data=tipo_pez.get()
    num_lote_data=num_lote.get()
    quelante_data=quelante.get()
    empacadora_data=empacadora.get()
    puerto_data=puerto.get()
    Hora_entrada_data=Hora_entrada.get()
    Hora_salida_data=Hora_salida.get()
    agua_data=agua.get()

    #print(tipo_pez_data,"\n",num_lote_data,"\n",quelante_data,"\n",empacadora_data,"\n",puerto_data,"\n",Hora_entrada_data,"\n",Hora_salida_data,"\n",agua_data)
    file=nom_archivo.get()+'.txt'
    newfile=open(file,"w")
    newfile.write("-Tipo de pez: " + tipo_pez_data)
    newfile.write("\n")
    newfile.write("-Lote: " + num_lote_data)
    newfile.write("\n")
    newfile.write("-¿Se le aplicó ácido lipóico? " + quelante_data)
    newfile.write("\n")
    newfile.write("-Nombre de la empacadora: " + empacadora_data)
    newfile.write("\n")
    newfile.write("-Nombre del puerto: " + puerto_data)
    newfile.write("\n")
    newfile.write("-Hora de entrada: " + Hora_entrada_data)
    newfile.write("\n")
    newfile.write("-Hora de salida: " + Hora_salida_data)
    newfile.write("\n")
    newfile.write("-Puerto: " + agua_data)
    newfile.write("\n")
    newfile.write("-Mapa de coordenadas de puertos pesqueros de el Golfo de California: https://goo.gl/maps/FXJWDcuxbPEEbGGKA")
    newfile.close()

    palcodigo=open(file,"r")
    p=palcodigo.read()

    palcodigo.close()
    img=qrcode.make(p)
    img.save(nom_archivo.get()+'.png')
    img.show(nom_archivo.get()+'.png')

    message_label=Label(text="¡Se subieron los datos!\nPuedes ingresar nueva información",bg=c,fg="white",font="Calibri 12 bold")
    message_label.place(x=380,y=430)

    botoncierre=tk.Button(ventanaprincipal,text="Cerrar",bg="white",font="Calibri 14 bold",activebackground="gray",activeforeground="white",relief="flat",command=cerrar)
    botoncierre.place(x=470,y=500)


c="turquoise4"
ventanaprincipal=tk.Tk()
ventanaprincipal.title("Traking Fish")
ventanaprincipal.geometry("650x550")
ventanaprincipal.configure(background=c)
ventanaprincipal.iconbitmap("Logo_HG1.ico")
titulo=tk.Label(text="HG Project",bg="gray",fg="white",font="Calibri 14 bold underline",width="550",height="1")
titulo.pack()


nom_archivo_label=Label(text="Ingresa el nombre del archivo:",bg=c,fg="white",font="Calibri 12 bold")
nom_archivo_label.place(x=25,y=50)

tipo_pez_label=Label(text="Ingresa el tipo de pez:",bg=c,fg="white",font="Calibri 12 bold")
tipo_pez_label.place(x=25,y=150)

num_lote_label=Label(text="Ingresa numero de lote:",bg=c,fg="white",font="Calibri 12 bold")
num_lote_label.place(x=25,y=100)

quelante_label=Label(text="¿Se le agrego acido lipoico insaturado antioxidante?",bg=c,fg="white",font="Calibri 12 bold")
quelante_label.place(x=25,y=200)

empacadora_label=Label(text="Ingresa el nombre de la empacadora:",bg=c,fg="white",font="Calibri 12 bold")
empacadora_label.place(x=25,y=250)

puerto_label=Label(text="Ingresa el nombre del puerto:",bg=c,fg="white",font="Calibri 12 bold")
puerto_label.place(x=25,y=300)

Hora_entrada_label=Label(text="Ingresa la hora de entra del pez a la empacadora:",bg=c,fg="white",font="Calibri 12 bold")
Hora_entrada_label.place(x=25,y=350)

Hora_salida_label=Label(text="Ingresa la hora de salida del pez a la empacadora:",bg=c,fg="white",font="Calibri 12 bold")
Hora_salida_label.place(x=25,y=400)

agua_label=Label(text="Ingrese el mar o rio donde se pescó:",bg=c,fg="white",font="Calibri 12 bold")
agua_label.place(x=25,y=450)


tipo_pez=StringVar()
num_lote=StringVar()
nom_archivo=StringVar()
quelante=StringVar()
empacadora=StringVar()
puerto=StringVar()
Hora_entrada=StringVar()
Hora_salida=StringVar()
agua=StringVar()


tipo_pez_in=Entry(textvariable=tipo_pez,width="40")
tipo_pez_in.place(x=30,y=180)
num_lote_in=Entry(textvariable=num_lote,width="40")
num_lote_in.place(x=30,y=130)
nom_archivo_in=Entry(textvariable=nom_archivo,width="40")
nom_archivo_in.place(x=30,y=80)
quelante_in=Entry(textvariable=quelante,width="40")
quelante_in.place(x=30,y=230)
empacadora_in=Entry(textvariable=empacadora,width="40")
empacadora_in.place(x=30,y=280)
puerto_in=Entry(textvariable=puerto,width="40")
puerto_in.place(x=30,y=330)
Hora_entrada_in=Entry(textvariable=Hora_entrada,width="40")
Hora_entrada_in.place(x=30,y=380)
Hora_salida_in=Entry(textvariable=Hora_salida,width="40")
Hora_salida_in.place(x=30,y=430)
agua_in=Entry(textvariable=agua,width="40")
agua_in.place(x=30,y=480)


boton=tk.Button(ventanaprincipal,text="Subir Datos",bg="white",font="Calibri 14 bold",activebackground="gray",activeforeground="white",relief="flat",command=escribir_datos)
boton.place(x=450,y=375)

image=tk.PhotoImage(file="Logo_HG1.gif")
image=image.subsample(3,3)
label=tk.Label(image=image)
label.place(x=390,y=90)

ventanaprincipal.mainloop()




